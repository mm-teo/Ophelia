      Movement.right.servo[2].angle = ad1
      Movement.right.servo[1].angle = fd1
      Movement.right.servo[0].angle = td1

      Movement.right.servo[5].angle = ad2
      Movement.right.servo[6].angle = fd2
      Movement.right.servo[7].angle = td2

      Movement.right.servo[13].angle = ad3
      Movement.right.servo[14].angle = fd3
      Movement.right.servo[15].angle = td3

      Movement.left.servo[13].angle = as1
      Movement.left.servo[14].angle = fs1
      Movement.left.servo[15].angle = ts1

      Movement.left.servo[5].angle = as2
      Movement.left.servo[6].angle = fs2
      Movement.left.servo[7].angle = ts2

      Movement.left.servo[2].angle = as3
      Movement.left.servo[1].angle = fs3
      Movement.left.servo[0].angle = ts3